from pathlib import Path
import json,math
import numpy as np
import block
R=Path(__file__).resolve().parent
old=block.leg(0,'left');h=np.array(old['hip']);x=3.55
# Visible knee-pad center is an approximate source annotation, not hidden joint measurement.
annotation=(214,244);n=np.array([.5,-math.sqrt(.75)])
target=(annotation[1]-336)/6;dist=target-n@h[1:]
center=h[1:]+dist*n;radius2=block.L1**2-(x-h[0])**2-dist**2
assert radius2>0
# Explicitly choose forward knee solution. Preserve source segment lengths.
yz=center+math.sqrt(radius2)*np.array([math.sqrt(.75),.5]);k=np.r_[x,yz]
a0=np.array(old['ankle']);direction=a0[1:]-yz
ankle=np.r_[a0[0],yz+direction/np.linalg.norm(direction)*math.sqrt(block.L2**2-(a0[0]-x)**2)]
new=dict(old);new['knee']=k.tolist();new['ankle']=ankle.tolist()
dy,dz=block.foot_rotation(-block.P['ankleBehindToe'],block.P['ankleAboveSole'],new['angle'])
new['toe']=[ankle[0],ankle[1]-dy,ankle[2]-dz]
hy,hz=block.foot_rotation(-block.P['footLength'],0,new['angle']);new['heel']=[ankle[0],new['toe'][1]+hy,new['toe'][2]+hz]
assert abs(math.dist(new['hip'],new['knee'])-block.L1)<1e-9
assert abs(math.dist(new['knee'],new['ankle'])-block.L2)<1e-9
(R/'authored-key.json').write_text(json.dumps(new,indent=2)+'\n')
(R/'key-comparison.json').write_text(json.dumps({'status':'AUTHORED_CONTACT_KEY_NOT_A_CYCLE','approximateVisibleKneePadAnnotation':annotation,'annotationIsAnatomicalJointMeasurement':False,'old':old,'new':new,'oldProjectedKnee':block.project(old['knee'],origin=(192,336)),'newProjectedKnee':block.project(new['knee'],origin=(192,336)),'segmentLengths':[math.dist(new['hip'],new['knee']),math.dist(new['knee'],new['ankle'])],'limits':'Forward branch selected by author; foot pitch retained; hidden ankle/toe proposed, not measured. Timing curve not updated.'},indent=2)+'\n')
