"""Offline source study renderer. Reads editable rig.json and original layer PNGs."""
from pathlib import Path
from PIL import Image
import argparse,json,math
ROOT=Path(__file__).resolve().parent
I=(1,0,0,0,1,0)
def compose(A,B):
 a,b,c,d,e,f=A;g,h,i,j,k,l=B
 return(a*g+b*j,a*h+b*k,a*i+b*l+c,d*g+e*j,d*h+e*k,d*i+e*l+f)
def around(angle,p):
 c=math.cos(math.radians(angle));s=math.sin(math.radians(angle));x,y=p
 return(c,-s,x-c*x+s*y,s,c,y-s*x-c*y)
def invert(A):
 a,b,c,d,e,f=A;det=a*e-b*d
 if abs(det)<1e-12:raise ValueError('Singular source transform')
 return(e/det,-b/det,(b*f-e*c)/det,-d/det,a/det,(d*c-a*f)/det)
def render(root,angles):
 rig=json.loads((root/'rig.json').read_text());bones=rig['bones'];transforms={}
 if set(angles)-set(bones):raise ValueError('Unknown joint names')
 if set(rig['boneOrder'])!=set(bones) or len(rig['boneOrder'])!=len(bones):raise ValueError('Invalid bone order')
 for name in rig['boneOrder']:
  bone=bones[name];parent=bone['parent'];angle=angles.get(name,0)
  if not isinstance(angle,(int,float)) or not math.isfinite(angle):raise ValueError('Invalid angle')
  if parent is not None and parent not in transforms:raise ValueError('Parent must precede child')
  transforms[name]=compose(transforms[parent] if parent else I,around(angle,bone['pivot']))
 out=Image.new('RGBA',(384,384))
 for name in reversed(rig['layerOrderTopToBottom']):
  im=Image.open(root/'source'/(name+'.png')).convert('RGBA')
  if im.size!=out.size:raise ValueError('Layer canvas mismatch')
  if name in rig['layerBindings']:
   matrix=transforms[rig['layerBindings'][name]]
   if any(abs(a-b)>1e-12 for a,b in zip(matrix,I)):
    im=im.transform(im.size,Image.Transform.AFFINE,invert(matrix),resample=Image.Resampling.BICUBIC)
  out.alpha_composite(im)
 return out
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--pose',type=int,default=0);parser.add_argument('--angles-file',type=Path);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 rig=json.loads((ROOT/'rig.json').read_text())
 if args.angles_file:angles=json.loads(args.angles_file.read_text())
 else:
  if not 0<=args.pose<len(rig['poses']):parser.error('pose index is out of range')
  angles=rig['poses'][args.pose]
 render(ROOT,angles).save(args.output)
