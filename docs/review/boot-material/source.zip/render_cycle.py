"""Render the owned boot source across all 16 revised poses. Diagnostic only."""
from pathlib import Path
from types import SimpleNamespace
import sys,json,hashlib
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent;S=R/'source';sys.path.insert(0,str(S))
geometry=(S/'boot_geometry.py').read_text().split("with (R/'recovery-leg.obj')")[0]
geometry=geometry.replace("leg=json.loads((R/'authored-key.json').read_text());","leg=POSE;")
owned=(S/'orientation.py').read_text()
owned_prefix=owned.split("with (R/'recovery-leg-owned.obj')")[0].replace('import boot_geometry as b','')
renderer='def render('+owned.split('def render(',1)[1].split("plate=Image.new('RGB',(840,840))",1)[0]
samples=json.loads((R/'samples.json').read_text());frames=[];records=[]
(R/'frames').mkdir(exist_ok=True)
for index,sample in enumerate(samples):
 legs=[];panels=[]
 for pose in sample['legs']:
  ns={'__file__':str(S/'boot_geometry.py'),'POSE':pose};exec(compile(geometry,'boot_geometry.py','exec'),ns)
  b=SimpleNamespace(**ns);renderns={'__file__':str(S/'orientation.py'),'b':b}
  exec(compile(owned_prefix+'\n'+renderer,'orientation.py','exec'),renderns)
  draw=renderns['render'];leg=draw(0,'',30,True);legs.append(leg)
  # Archive per-pose editable surface mesh, not just flattened images.
  stem=f'{index:02d}-{pose["side"]}'
  with (R/'frames'/(stem+'.obj')).open('w') as out:
   for p in renderns['verts']:out.write('v '+' '.join(map(str,p))+'\n')
   for group,face in zip(renderns['groups'],renderns['faces']):out.write('g '+group+'\nf '+' '.join(str(i+1) for i in face)+'\n')
  leg.save(R/'frames'/(stem+'.png'))
  original=renderns['colors']
  renderns['colors']=[(245,35,180) if 'laces' in group else (85,90,95) for group in renderns['groups']]
  front=draw(0,'FRONT: magenta = visible laces');back=draw(180,'BACK: same geometry + depth test')
  pan=Image.new('RGB',(840,420));pan.paste(front,(0,0));pan.paste(back,(420,0));panels.append(pan)
  records.append({'frame':index,'side':pose['side'],'time':sample['time'],'mesh':stem+'.obj','laceFaces':sum('laces' in g for g in renderns['groups']),'laceGroups':sorted(set(g for g in renderns['groups'] if 'laces' in g))})
 combined=Image.new('RGBA',(384,416))
 for leg in legs:combined.alpha_composite(leg)
 combined.save(R/'frames'/f'{index:02d}-both.png')
 plate=Image.new('RGB',(1224,840),'#263036');d=ImageDraw.Draw(plate)
 plate.paste(combined,(0,160),combined);d.text((12,12),f'Boot source {index+1:02d}/16 — not final art',fill='white')
 for i,p in enumerate(panels):plate.paste(p,(384,i*420))
 frames.append(plate)
frames[0].save(R/'surface-cycle.gif',save_all=True,append_images=frames[1:],duration=125,loop=0)
# Four phase samples at useful viewing size, separate from the moving preview.
contact=Image.new('RGB',(1536,448),'#263036');d=ImageDraw.Draw(contact)
for col,i in enumerate([0,4,8,12]):
 im=Image.open(R/'frames'/f'{i:02d}-both.png');contact.paste(im,(col*384,32),im);d.text((col*384+12,12),f'Frame {i+1:02d}',fill='white')
contact.save(R/'phase-review.png')
assert len(records)==32 and all(r['laceGroups']==['laces_instep','laces_shaft_front'] for r in records)
(R/'render-record.json').write_text(json.dumps({'status':'OWNED_BOOT_SOURCE_RANGE_DIAGNOSTIC','frames':records,'durationSeconds':.5,'previewFrameMilliseconds':125,'productionArt':False,'materials':'flat authored proxy colors; magenta diagnostic marks only lace surfaces','renderer':'orthographic depth buffer; same source mesh for front/back','limitations':['No thigh, torso or cloth animation','No costume-material fidelity claim','No whole-character inter-limb occlusion validation','No runtime travel test']},indent=2)+'\n')
print('32 boot meshes and 16 paired renders exported; surface group checks passed.')
