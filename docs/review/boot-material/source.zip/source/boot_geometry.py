"""Editable pose guide only: authored geometry, never inferred anatomy or finished art."""
from pathlib import Path
import math,json
from PIL import Image,ImageDraw
import block
R=Path(__file__).resolve().parent
P=json.loads((R/'boot-shape.json').read_text())
leg=json.loads((R/'authored-key.json').read_text());vertices=[];faces=[];colors=[]
def add(v):vertices.append(tuple(v));return len(vertices)-1
def face(ids,color):faces.append(ids);colors.append(color)
def point(x,y,z):
 dy,dz=block.foot_rotation(y,z,leg['angle'])
 return (leg['toe'][0]+x,leg['toe'][1]+dy,leg['toe'][2]+dz)
# A closed, rounded shoe volume follows the SAME authored heel/toe and pitch.
rings=[]
for y,w,h in P['sections']:
 ring=[(-w*.65,0),(-w,.35),(-w*.95,h*.65),(-w*.55,h),(w*.55,h),(w*.95,h*.65),(w,.35),(w*.65,0)]
 rings.append([add(point(x,y,z)) for x,z in ring])
for a,b in zip(rings,rings[1:]):
 for j in range(8):face([a[j],a[(j+1)%8],b[(j+1)%8],b[j]],(103,79,49) if j!=7 else (40,35,29))
face(list(reversed(rings[0])),(70,54,35));face(rings[-1],(103,79,49))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def norm(v):
 n=math.sqrt(sum(x*x for x in v));return tuple(x/n for x in v)
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
axis=norm(sub(leg['knee'],leg['ankle']));u=norm(cross(axis,(1,0,0)));v=cross(axis,u)
# Boot shaft follows the shin instead of continuing in a different direction.
def tube(distances,radius,color):
 rr=[]
 for dist in distances:
  c=tuple(leg['ankle'][i]+axis[i]*dist for i in range(3))
  rr.append([add(tuple(c[i]+radius*(math.cos(j*math.tau/12)*u[i]+math.sin(j*math.tau/12)*v[i]) for i in range(3))) for j in range(12)])
 for a,b in zip(rr,rr[1:]):
  for j in range(12):face([a[j],a[(j+1)%12],b[(j+1)%12],b[j]],color)
 face(list(reversed(rr[0])),color);face(rr[-1],color)
tube([-.8,3.6],1.55,(105,82,52));tube([3.6,13.5],1.45,(63,65,62))
with (R/'recovery-leg.obj').open('w') as f:
 f.write('# Authored recovery-leg pose guide; no texture or art admission\n')
 for p in vertices:f.write('v '+' '.join(map(str,p))+'\n')
 for q in faces:f.write('f '+' '.join(str(i+1) for i in q)+'\n')
def render(side=False):
 im=Image.new('RGB',(450,450),'#283036');d=ImageDraw.Draw(im)
 def proj(p):
  x,y,z=p
  return (225+12*((y-leg['ankle'][1]) if side else (x-leg['ankle'][0])),235+12*(-(z-leg['ankle'][2]) if side else ((y-leg['ankle'][1])*.5-(z-leg['ankle'][2])*math.sqrt(.75))))
 def depth(i):
  ps=[vertices[n] for n in faces[i]]
  return sum(p[0] if side else p[1]*math.sqrt(.75)+p[2]*.5 for p in ps)/len(ps)
 for i in sorted(range(len(faces)),key=depth):
  pts=[vertices[j] for j in faces[i]];normal=norm(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0])))
  light=.48+.52*abs(sum(a*b for a,b in zip(normal,norm((-.5,1,2)))))
  color=tuple(round(c*light) for c in colors[i]);d.polygon([proj(p) for p in pts],fill=color,outline=(51,52,49))
 for name in ['knee','ankle','heel','toe']:
  x,y=proj(leg[name]);d.ellipse((x-3,y-3,x+3,y+3),fill='#8ce2ed');d.text((x+6,y-4),name,fill='#b1eff5')
 d.text((12,12),'SIDE DIAGNOSTIC' if side else 'ELEVATED SOUTH — RECOVERY LEG',fill='white')
 return im
plate=Image.new('RGB',(900,450));plate.paste(render(),(0,0));plate.paste(render(True),(450,0));plate.save(R/'geometry-guide.png')
from collections import Counter
edges=Counter(tuple(sorted((f[i],f[(i+1)%len(f)]))) for f in faces for i in range(len(f)))
assert all(count==2 for count in edges.values()), 'Every component edge must have two incident faces'
assert len(vertices)==len(set(vertices))
assert all(len(set(f))==len(f) for f in faces)
assert all(math.isfinite(x) for p in vertices for x in p)
# The mesh is subordinate to the inherited pose; endpoint annotations are not moved to fit painting.
(R/'geometry-record.json').write_text(json.dumps({'status':'AUTHORED_GEOMETRY_GUIDE_NOT_FINAL_ART','poseTime':0,'side':'left','vertices':len(vertices),'faces':len(faces),'landmarks':leg,'shapeParameters':P,'projection':{'elevationDegrees':30,'comparisonScale':12},'hiddenAnatomyMeasured':False},indent=2)+'\n')
