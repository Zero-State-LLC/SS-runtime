from pathlib import Path
import json,math
import numpy as np
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parent
old=json.loads((R/'prior-samples.json').read_text());new=[];rows=[]
for sample in old:
 legs=[]
 for pose in sample['legs']:
  q=dict(pose);a=math.radians(q['angle']);toe=np.array(q['toe']);ankle=toe+np.array([0,-7.5*math.cos(a)+3*math.sin(a),7.5*math.sin(a)+3*math.cos(a)])
  h=np.array(q['hip']);x=(h[0]+ankle[0])/2;r1=math.sqrt(13.5**2-(x-h[0])**2);r2=math.sqrt(13.5**2-(ankle[0]-x)**2)
  dy,dz=ankle[1]-h[1],ankle[2]-h[2];d=math.hypot(dy,dz);assert abs(r1-r2)<d<r1+r2 and dz<0
  along=(r1*r1-r2*r2+d*d)/(2*d);bend=math.sqrt(r1*r1-along*along)
  knee=np.array([x,h[1]+along*dy/d-bend*dz/d,h[2]+along*dz/d+bend*dy/d])
  q['ankle']=ankle.tolist();q['knee']=knee.tolist();legs.append(q)
  assert abs(np.linalg.norm(knee-h)-13.5)<1e-9 and abs(np.linalg.norm(ankle-knee)-13.5)<1e-9
  rows.append({'time':sample['time'],'side':q['side'],'toeUnchanged':q['toe']==pose['toe'],'heelUnchanged':q['heel']==pose['heel'],'kneeDisplacementSourceUnits':float(np.linalg.norm(knee-np.array(pose['knee'])))})
 new.append({'time':sample['time'],'legs':legs})
(R/'candidate-samples.json').write_text(json.dumps(new,indent=2)+'\n')
(R/'verification.json').write_text(json.dumps({'status':'PROPOSED_ANKLE_PLACEMENT_COMPARISON_NOT_ANATOMICAL_MEASUREMENT','oldAnkleBehindToe':5,'candidateAnkleBehindToe':7.5,'footLength':10,'visibleSourceAnnotations':{'eastForegroundBootHeelX':156,'eastForegroundBootToeX':224,'eastForegroundLowerShaftCenterX':173,'annotationStatus':'approximate visible silhouette/lower shaft, NOT hidden ankle joint'},'rows':rows},indent=2)+'\n')
# Source model silhouette comparison, same neutral shoe length/pose. Cyan line identifies ankle axis.
im=Image.new('RGB',(800,300),'#283036');d=ImageDraw.Draw(im)
for i,(behind,label) in enumerate([(5,'Current: ankle halfway along shoe'),(7.5,'Candidate: ankle nearer retained heel')]):
 ox=50+i*400;ground=245;scale=25
 d.polygon([(ox,ground),(ox,ground-60),(ox+60,ground-65),(ox+170,ground-45),(ox+250,ground-20),(ox+250,ground)],fill='#70583e',outline='#c1ad85')
 x=ox+(10-behind)*scale;d.polygon([(x-30,ground-50),(x-30,ground-175),(x+30,ground-175),(x+30,ground-50)],fill='#70583e',outline='#c1ad85')
 d.line((x,ground-190,x,ground),fill='#8ed5db',width=2);d.text((ox,15),label,fill='white')
 d.text((ox,265),'Diagram only; not a finished boot mesh',fill='#b5bcc0')
im.save(R/'proportion-comparison.png')
print('32 candidate poses preserve original heel/toe paths and both 13.5-unit limb lengths.')
