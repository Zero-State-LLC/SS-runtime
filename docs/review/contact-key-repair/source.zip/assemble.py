from pathlib import Path
from PIL import Image,ImageDraw,ImageChops
import json,hashlib,shutil
r=Path(__file__).resolve().parent
prior=r/'baseline'
settings=json.loads((r/'registration.json').read_text())
source=Image.open(r/'source.png').convert('RGBA')
scale=settings['uniformScale'];tx,ty=settings['translation']
registered=source.transform((384,416),Image.Transform.AFFINE,(1/scale,0,-tx/scale,0,1/scale,-ty/scale),Image.Resampling.BICUBIC)
registered.save(r/'registered.png')
mask=Image.new('L',(384,416));ImageDraw.Draw(mask).polygon([tuple(p) for p in settings['leadLegPolygon']],fill=255)
new=registered.copy();new.putalpha(ImageChops.multiply(new.getchannel('A'),mask));new.save(r/'lead-leg.png')
old=Image.open(prior/'contact-legs.png').convert('RGBA')
old.putalpha(ImageChops.multiply(old.getchannel('A'),ImageChops.invert(mask)))
legs=Image.alpha_composite(old,new);legs.save(r/'contact-legs.png')
rig=json.loads((prior/'body-rig.json').read_text());combined=legs.copy()
for name in reversed(rig['layerOrderTopToBottom']):
 if any(k in name for k in ['thigh','shin_boot','boot','hip_hidden','knee_hidden']):continue
 combined.alpha_composite(Image.open(prior/'body-source'/(name+'.png')).convert('RGBA'))
original=Image.open(prior/'retained-neutral.png').convert('RGBA')
combined.paste(original.crop((0,0,384,199)),(0,0));combined.save(r/'retained-body-contact.png')
assert original.crop((0,0,384,199)).tobytes()==combined.crop((0,0,384,199)).tobytes()
plate=Image.new('RGB',(1152,456),'#30373b');d=ImageDraw.Draw(plate)
for i,(p,label) in enumerate([(prior/'retained-body-contact.png','Previous contact key'),(r/'retained-body-contact.png','Repaired lead leg; original body'),(r/'retained-body-contact.png','Authored guide overlay')]):
 im=Image.open(p).convert('RGBA');plate.paste(im,(i*384,32),im);d.text((i*384+10,10),label,fill='white')
 if i==2:
  guide=json.loads((prior/'contact-guide-points.json').read_text())['right']
  points=[tuple(guide[n]) for n in ['hip','knee','ankle','heel','toe']]
  d.line([(x+768,y+32) for x,y in points],fill='#ebba66',width=1)
  for name,(x,y) in guide.items():
   d.ellipse((x+766,y+30,x+770,y+34),fill='#ebba66');d.text((x+775,y+27),name,fill='#ebba66')
plate.save(r/'comparison.png')
landmarks=settings['approximateSourceLandmarks']
guide=json.loads((prior/'contact-guide-points.json').read_text())['right']
measured={}
for name,p in landmarks.items():
 target=[p[0]*scale+tx,p[1]*scale+ty];expected=guide[name]
 measured[name]={'registeredApproximation':target,'authoredGuide':expected,'delta':[target[0]-expected[0],target[1]-expected[1]]}
(r/'verification.json').write_text(json.dumps({'upperRegionExactRGBA':True,'measurementStatus':'manual visible-landmark estimates; not hidden anatomy or a pass threshold','landmarks':measured,'sourceSHA256':hashlib.sha256((r/'source.png').read_bytes()).hexdigest()},indent=2)+'\n')
