from pathlib import Path
from PIL import Image,ImageDraw
import importlib.util,json
r=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cloth_source',r/'render_source.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rig=json.loads((r/'rig.json').read_text());original=Image.open(r.parent/'SS-foot-cloth-controls/neutral.png').convert('RGBA')
assert m.render(r,{}).tobytes()==original.tobytes()
frames=[];results=[]
for index,offset in enumerate([0,2,4,2,0,-2,-4,-2]):
 controls={'right_coat_tail':offset,'left_coat_tail':-offset};out=m.render(r,{},controls)
 # The whole figure above the fixed roots is untouched by this source operation.
 assert out.crop((0,0,384,210)).tobytes()==original.crop((0,0,384,210)).tobytes()
 for name,value in controls.items():
  part=Image.open(r/'source'/(name+'.png')).convert('RGBA');warped=m.deform_cloth(part,rig['meshDeformations'][name],value)
  assert warped.crop((0,0,384,210)).tobytes()==part.crop((0,0,384,210)).tobytes()
  if value!=0:assert warped.tobytes()!=part.tobytes()
 out.save(r/f'frame-{index:02d}.png')
 frame=Image.new('RGB',(768,420),(55,55,55));d=ImageDraw.Draw(frame)
 for col,im in enumerate([original,out]):
  base=Image.new('RGBA',im.size,(55,55,55,255));base.alpha_composite(im);frame.paste(base.convert('RGB'),(col*384,30));d.text((col*384+10,10),'Original neutral' if col==0 else f'Anchored cloth study / {offset:+} px',fill='white')
 frames.append(frame);results.append({'frame':index,'deformations':controls,'rootRowsUnchanged':True})
frames[0].save(r/'cloth-review.gif',save_all=True,append_images=frames[1:],duration=180,loop=0)
plate=Image.new('RGB',(960,320),(55,55,55));d=ImageDraw.Draw(plate)
for col,index in enumerate([0,2,6]):
 im=Image.open(r/f'frame-{index:02d}.png').convert('RGBA');base=Image.new('RGBA',im.size,(55,55,55,255));base.alpha_composite(im)
 crop=base.crop((115,188,270,270)).resize((310,164),Image.Resampling.NEAREST);plate.paste(crop.convert('RGB'),(col*320,50));d.text((col*320+10,15),['Neutral','Hem offsets +4/-4','Hem offsets -4/+4'][col],fill='white')
plate.save(r/'cloth-endpoints.png')
(r/'diagnostic-poses.json').write_text(json.dumps(results,indent=2)+'\n')
(r/'verification.json').write_text(json.dumps({'neutralExact':True,'allPixelsAboveSourceRow210Unchanged':True,'nonzeroHemControlsChangeClothPixels':True,'diagnosticFrames':8,'simulationOrRuntimeAcceptance':False,'motionType':'horizontal anchored source deformation only'},indent=2)+'\n')
print('Neutral and fixed attachment rows exact in all eight source poses; hem controls change cloth.')
