from pathlib import Path
import importlib.util,json
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('block',r/'block.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
im=Image.new('RGB',(768,448),'#20272b');d=ImageDraw.Draw(im)
source=Image.open(r/'retained-neutral.png');im.paste(source,(0,32),source)
d.text((12,10),'COSTUME / ORIGINAL NEUTRAL',fill='white');d.text((396,10),'CONTACT POSE / GEOMETRY GUIDE',fill='white')
q=b.pose(0)
points={}
def project(p): return b.project(p,origin=(576,368))
# Full body contour is not synthesized; gray outline records original torso location only.
d.rectangle((504,70,648,240),outline='#52636e',width=1)
d.text((508,82),'keep original',fill='#9aa7ad');d.text((508,98),'hood / torso',fill='#9aa7ad')
for l in q['legs']:
 color='#e9af69' if l['side']=='right' else '#79bfcd'
 pts=[project(l[k]) for k in ['hip','knee','ankle']];d.line(pts,fill=color,width=10)
 points[l['side']]={k:list(b.project(l[k],origin=(192,336))) for k in ['hip','knee','ankle','heel','toe']}
 for k in ['hip','knee','ankle','heel','toe']:
  px,py=project(l[k]);d.ellipse((px-3,py-3,px+3,py+3),fill='white')
  d.text((px+7,py-6),k,fill=color)
 d.line([project(l['heel']),project(l['toe'])],fill=color,width=9)
 if l['contact']:
  px,py=project(l['toe']);d.line([(px-24,py),(px+24,py)],fill='#a9f79a',width=2)
d.text((396,426),'Orange: right support. Blue: left recovery.',fill='white')
im.save(r/'contact-guide.png');(r/'contact-guide-points.json').write_text(json.dumps(points,indent=2)+'\n')
