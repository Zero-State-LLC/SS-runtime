from pathlib import Path
from PIL import Image,ImageDraw,ImageChops
import json
r=Path(__file__).resolve().parent
settings=json.loads((r/'contact-extraction.json').read_text())
im=Image.open(r/'recovery-corrected-source.png').convert('RGBA')
scale=settings['uniformScale'];tx,ty=settings['translation']
reg=im.transform((384,416),Image.Transform.AFFINE,(1/scale,0,-tx/scale,0,1/scale,-ty/scale),Image.Resampling.BICUBIC)
reg.save(r/'corrected-registered.png')
mask=Image.new('L',reg.size);ImageDraw.Draw(mask).polygon([tuple(p) for p in settings['polygon']],fill=255)
reg.putalpha(ImageChops.multiply(reg.getchannel('A'),mask))
clean=Image.new('RGBA',reg.size);clean.alpha_composite(reg);clean.save(r/'contact-legs.png')
rig=json.loads((r/'body-rig.json').read_text());combined=clean.copy()
for name in reversed(rig['layerOrderTopToBottom']):
 if any(k in name for k in ['thigh','shin_boot','boot','hip_hidden','knee_hidden']): continue
 combined.alpha_composite(Image.open(r/'body-source'/(name+'.png')).convert('RGBA'))
original=Image.open(r/'retained-neutral.png').convert('RGBA')
# Preserve the entire original region above the edited lower body, including antialiased seams.
combined.paste(original.crop((0,0,384,199)),(0,0))
combined.save(r/'retained-body-contact.png')
imgs=[]
for name in ['retained-neutral.png','corrected-registered.png','retained-body-contact.png']:
 a=Image.open(r/name).convert('RGBA');p=Image.new('RGBA',(384,416));p.alpha_composite(a);imgs.append(p)
comparison=Image.new('RGB',(1152,456),'#30373b');d=ImageDraw.Draw(comparison)
for i,(im,label) in enumerate(zip(imgs,['Original neutral','Generated correction (registered)','Original body + contact legs'])):
 comparison.paste(im,(i*384,32),im);d.text((i*384+12,12),label,fill='white')
comparison.save(r/'comparison.png')
assert original.crop((0,0,384,199)).tobytes()==combined.crop((0,0,384,199)).tobytes()
print('Original upper region: exact RGBA preservation above row 199.')
