"""Source-motion candidate, not production character animation."""
from pathlib import Path
import json,math
from PIL import Image,ImageDraw
import block
R=Path(__file__).resolve().parent
key=json.loads((R/'authored-key.json').read_text());oldkey=block.leg(0,'left')
offset=[key['ankle'][i]-oldkey['ankle'][i] for i in range(3)]
u_key=(key['phase']-block.S)/(block.C-block.S)
normalization=math.sin(math.pi*u_key)**2

def corrected(t,side):
 q=block.leg(t,side);h=q['hip'];a=list(q['ankle'])
 if not q['contact']:
  u=(q['phase']-block.S)/(block.C-block.S)
  weight=math.sin(math.pi*u)**2/normalization
  a=[a[i]+offset[i]*weight for i in range(3)]
 # Constrain knee lateral position explicitly; solve the remaining two dimensions.
 x=(h[0]+a[0])/2;r1=math.sqrt(block.L1**2-(x-h[0])**2);r2=math.sqrt(block.L2**2-(a[0]-x)**2)
 dy,dz=a[1]-h[1],a[2]-h[2];d=math.hypot(dy,dz)
 if not abs(r1-r2)<d<r1+r2:raise ValueError(('unreachable',t,side,d))
 along=(r1*r1-r2*r2+d*d)/(2*d);bend=math.sqrt(r1*r1-along*along)
 # The candidate stays below the hip. This branch places the knee forward.
 assert dz<0,('pole branch needs review',t,side)
 knee=(x,h[1]+along*dy/d-bend*dz/d,h[2]+along*dz/d+bend*dy/d)
 q['knee']=knee;q['ankle']=a
 dy,dz=block.foot_rotation(-block.P['ankleBehindToe'],block.P['ankleAboveSole'],q['angle'])
 q['toe']=(a[0],a[1]-dy,a[2]-dz)
 hy,hz=block.foot_rotation(-block.P['footLength'],0,q['angle']);q['heel']=(a[0],q['toe'][1]+hy,q['toe'][2]+hz)
 return q

def frame(t,solver,label):
 im=Image.new('RGB',(384,416),'#263036');d=ImageDraw.Draw(im)
 def project(p):return block.project(p,origin=(192,336))
 for y in range(-20,31,10):d.line([project((-25,y,0)),project((25,y,0))],fill='#3b4447')
 for side in ['left','right']:
  q=solver(t,side);color='#e3b46a' if side=='right' else '#83c4cf'
  d.line([project(q[k]) for k in ['hip','knee','ankle']],fill=color,width=10)
  for k in ['hip','knee','ankle']:
   x,y=project(q[k]);d.ellipse((x-3,y-3,x+3,y+3),fill='white')
  sole=[(p[0]+w,p[1],p[2]) for p,w in [(q['heel'],-2),(q['heel'],2),(q['toe'],2),(q['toe'],-2)]]
  d.polygon([project(p) for p in sole],fill=color,outline='white')
  if q['contact']:
   x,y=project(q['toe']);d.ellipse((x-5,y-5,x+5,y+5),outline='#a7e899',width=2)
 d.text((12,12),label,fill='white');d.text((12,32),f't={t:.5f}s',fill='white');return im
samples=[{'time':i*block.C/16,'legs':[corrected(i*block.C/16,s) for s in ['right','left']]} for i in range(16)]
errors=[];drift=[];clearance=[]
for i in range(1001):
 t=i*block.C/1000
 for side in ['right','left']:
  q=corrected(t,side);old=block.leg(t,side)
  errors.extend([abs(math.dist(q['hip'],q['knee'])-block.L1),abs(math.dist(q['knee'],q['ankle'])-block.L2)])
  clearance.extend([q['heel'][2],q['toe'][2]])
  if q['contact']:drift.append(math.dist(q['toe'],old['toe']))
seam=max(math.dist(corrected(0,s)[k],corrected(block.C,s)[k]) for s in ['right','left'] for k in ['hip','knee','ankle','heel','toe'])
keyerror=max(math.dist(corrected(0,'left')[k],key[k]) for k in ['hip','knee','ankle','heel','toe'])
assert max(errors)<1e-9 and max(drift)<1e-9 and seam<1e-9 and keyerror<1e-9 and min(clearance)>-1e-9
frames=[]
for i in range(16):
 t=i*block.C/16;im=Image.new('RGB',(768,416));im.paste(frame(t,block.leg,'Prior source'),(0,0));im.paste(frame(t,corrected,'Corrected recovery source'),(384,0));frames.append(im)
frames[0].save(R/'slow-comparison.gif',save_all=True,append_images=frames[1:],duration=125,loop=0)
sheet=Image.new('RGB',(1536,1664))
for i in range(16):sheet.paste(frame(i*block.C/16,corrected,f'Frame {i+1:02d}'),(i%4*384,i//4*416))
sheet.save(R/'sixteen-source-poses.png')
(R/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
record={'status':'SOURCE_GEOMETRY_NOT_ART_OR_RUNTIME','cycleSeconds':block.C,'uniqueSampleTimes':16,'denseSamples':1001,'ankleCorrectionAtAuthoredKey':offset,'swingEnvelope':'sin(pi*u)^2 / sin(pi*u_key)^2','uKey':u_key,'maxSegmentLengthError':max(errors),'supportToeDifferenceFromPriorSource':max(drift),'seamPositionDifference':seam,'authoredKeyDifference':keyerror,'minimumHeelToeHeight':min(clearance),'runtimeTravelVerified':False,'heldFrameSlidingResolved':False,'costumeOrClothAnimated':False,'gifDuration':'125ms per frame, intentionally slow diagnostic; not shipping cadence'}
(R/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
