from pathlib import Path
from collections import Counter,defaultdict
import sys,json,numpy as np
R=Path(__file__).resolve().parent;S=R/'source';sys.path.insert(0,str(S))
code=(S/'boot_geometry.py').read_text().split("with (R/'recovery-leg.obj')")[0].replace("leg=json.loads((R/'authored-key.json').read_text());","leg=POSE;")
rows=[]
for sample in json.loads((R/'samples.json').read_text()):
 for pose in sample['legs']:
  ns={'__file__':str(S/'boot_geometry.py'),'POSE':pose};exec(compile(code,'boot_geometry.py','exec'),ns)
  fs=ns['faces'][:ns['boot_face_count']];vs=np.array(ns['vertices'][:ns['boot_vertex_count']]);edges=Counter();directions=Counter();adj=defaultdict(set)
  for face in fs:
   for i,a in enumerate(face):
    b=face[(i+1)%len(face)];edges[tuple(sorted((a,b)))]+=1;directions[a,b]+=1;adj[a].add(b);adj[b].add(a)
  assert all(n==2 for n in edges.values())
  assert all(directions[a,b]==directions[b,a] for a,b in directions)
  unseen=set(adj);components=0
  while unseen:
   components+=1;todo=[unseen.pop()]
   while todo:
    for b in adj[todo.pop()]:
     if b in unseen:unseen.remove(b);todo.append(b)
  assert components==1
  assert len(vs)-len(edges)+len(fs)==2
  origin=np.array(ns['point'](0,0,0));basis=np.array([np.array(ns['point'](*p))-origin for p in [(1,0,0),(0,1,0),(0,0,1)]])
  soleids={i for face,g in zip(fs,ns['face_groups']) if g=='boot_sole' for i in face};sole=(vs[list(soleids)]-origin)@basis.T
  assert abs(sole[:,2]).max()<1e-9
  rows.append({'time':sample['time'],'side':pose['side'],'bootConnectedComponents':components,'bootVertices':len(vs),'bootFaces':len(fs),'opposingEdgeWinding':True,'eulerCharacteristic':2,'maxSolePlaneError':float(abs(sole[:,2]).max())})
(R/'mesh-verification.json').write_text(json.dumps(rows,indent=2)+'\n')
print('32 boots: one closed oriented component each; authored sole-plane checks passed.')
